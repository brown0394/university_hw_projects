    struct Data;
    typedef struct Data Data;

    struct Node;
    typedef struct Node Node;
    typedef struct Node *List;

    typedef enum {INT, OP} TAG;
    typedef enum {UNARY, BINARY, INTVAL} NKind;

    struct Node {
       NKind kind;
       Data *val;
       List son;
       List bro;
    };

    struct Data {
       TAG tag;
       union {
       int intval;
       char opval;
       };
    };


List cons(Data* n, List ls);
Data *mkint(int n);
Data *mkchr(char c);
List unary(List p, List son);
void addSon(List parent, List son);
void addBro(List me, List bro);
List binary(List p, List son1, List son2);
void printStack(List head);
void printall(List head);
void printblank();

List cons(Data* n, List ls) {
    List newnode = (List)malloc(sizeof *newnode);
    newnode->son = ls;
    newnode->bro = NULL;
    newnode->val = n;
    return newnode;
}

Data *mkint(int n) {
    Data* newdata = (Data *)malloc(sizeof *newdata);
    newdata->tag = INT;
    newdata->intval = n;
    return newdata;
}

Data *mkchr(char c) {
    Data* newdata = (Data *)malloc(sizeof *newdata);
    newdata->tag = OP;
    newdata->opval = c;
    return newdata;
}
List unary(List p, List son) {
    p->kind = UNARY;
    addSon(p, son);
    return p;
}
void addSon(List parent, List son) {
    if (parent->son == NULL) parent->son = son;
    else addBro(parent->son, son);
}
void addBro(List me, List bro) {
    List temp = me;
    while (temp->bro != NULL) {
       temp = temp->bro;
    }
    temp->bro = bro;
}
List binary(List p, List son1, List son2) {
    p->kind = BINARY;
    addBro(son1, son2);
    addSon(p, son1);
    return p;
}

void printStack(List head) {
    if (head->son != NULL) {
       printStack(head->son);
    }


    if (head->kind == INTVAL) printf("ldc %d\n", head->val->intval);
    else if (head->kind == UNARY) {
        if (head->val->opval == '-') printf("neg\n", head->val->opval);
    }
    else {
         switch(head->val->opval) {
             case '+': { printf("add\n"); break; }
             case '-': { printf("sub\n"); break; }
             case '*': { printf("mul\n"); break; }
             case '/': { printf("div\n"); break; }
	 }
    }
    if(head->bro != NULL) {
       printStack(head->bro);
    }
}

void printall(List head) {
    static int cnt = 0;
    for (int i = 0; i < cnt; ++i) { printblank(); }
    if (head->kind == INTVAL) printf("%d\n", head->val->intval);
    else if (head->kind == UNARY) printf("(%c)\n", head->val->opval);
    else printf("%c\n", head->val->opval);
    if (head->son != NULL) {
       ++cnt;
       printall(head->son);
       --cnt;
    }
    if(head->bro != NULL) {
       printall(head->bro);
    }
}
void printblank() {
    printf("  ");
}

